
Prise en main avec Create React App
Ce projet a été initialisé avec Create React App.

Scripts disponibles
Dans le répertoire du projet, vous pouvez exécuter :
### `npm install`

### `npm start`

Lance l'application en mode développement.
Ouvrez http://localhost:3000 pour l'afficher dans le navigateur.

La page se rechargera si vous apportez des modifications.
Vous verrez également toutes les erreurs de lint dans la console.
### `npm test`

Lance le testeur en mode interactif de surveillance.
Voir la section sur l'exécution des tests pour plus d'informations.
### `npm run build`

Compile l'application pour la production dans le dossier build.
Il regroupe correctement React en mode production et optimise la compilation pour de meilleures performances.
